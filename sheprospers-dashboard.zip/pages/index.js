import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const res = await fetch('/api/products');
      const data = await res.json();
      setProducts(data.records || []);
    }
    fetchData();
  }, []);

  return (
    <div style={{ padding: '2rem' }}>
      <h1>She Prospers Dashboard</h1>
      <h2>Top Products</h2>
      <ul>
        {products.map((item) => (
          <li key={item.id}>{item.fields.Name}</li>
        ))}
      </ul>
    </div>
  );
}